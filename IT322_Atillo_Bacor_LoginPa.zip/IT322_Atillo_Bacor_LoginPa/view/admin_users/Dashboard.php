<?php
include("../../auth/authentication_for_user.php");
include("./includes/header.php");
include("./includes/topbar.php");
include("./includes/sidebar.php");
?>

<?php
include("../../dB/config.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Clock In/Out Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .card {
      border-radius: 1rem;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .btn-clock {
      width: 100%;
      padding: 1rem;
      font-size: 1.2rem;
    }
    .timestamp {
      font-size: 1.1rem;
      color: #6c757d;
    }
    .history-table {
      margin-top: 2rem;
    }
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card p-4 text-center">
          <h2 class="mb-4">Attendance Dashboard</h2>

          <div class="d-grid gap-3 mb-4">
            <button class="btn btn-success btn-clock rounded-5" onclick="clockIn()">🟢 Clock In</button>
            <button class="btn btn-danger btn-clock rounded-5" onclick="clockOut()">🔴 Clock Out</button>
          </div>

          <div class="border-top pt-3">
            <p class="mb-1 timestamp"><strong>Last Clock In:</strong> <span id="lastClockIn">--:--</span></p>
            <p class="mb-0 timestamp"><strong>Last Clock Out:</strong> <span id="lastClockOut">--:--</span></p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    function clockIn() {
      const time = new Date().toLocaleTimeString();
      document.getElementById('lastClockIn').textContent = time;
      alert('Clocked In at ' + time);
    }

    function clockOut() {
      const time = new Date().toLocaleTimeString();
      document.getElementById('lastClockOut').textContent = time;
      alert('Clocked Out at ' + time);
    }
  </script>
</body>
</html>

<?php
include("./includes/footer.php");
?>