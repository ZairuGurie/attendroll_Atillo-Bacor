<?php
include("../../auth/authentication_for_user.php");
include("./includes/header.php");
include("./includes/topbar.php");
include("./includes/sidebar.php");
?>

<?php
include("../../dB/config.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Salary Details</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .card {
      border-radius: 1rem;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .table td, .table th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-15">
        <div class="card p-4">
          <h3 class="text-center mb-4">Salary Details</h3>
          <div class="table-responsive">
            <table class="table table-bordered table-striped">
              <thead class="table-dark">
                <tr>
                  <th>Description</th>
                  <th>Amount (USD)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Basic Salary</td>
                  <td>$2,500.00</td>
                </tr>
                <tr>
                  <td>Housing Allowance</td>
                  <td>$500.00</td>
                </tr>
                <tr>
                  <td>Transport Allowance</td>
                  <td>$200.00</td>
                </tr>
                <tr>
                  <td>Bonuses</td>
                  <td>$300.00</td>
                </tr>
                <tr class="table-danger">
                  <td>Tax Deduction</td>
                  <td>-$400.00</td>
                </tr>
                <tr class="table-warning">
                  <td>Other Deductions</td>
                  <td>-$100.00</td>
                </tr>
                <tr class="table-success">
                  <th>Total Net Pay</th>
                  <th>$3,000.00</th>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
<?php
include("./includes/footer.php");
?>