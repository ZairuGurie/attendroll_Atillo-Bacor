<?php
include("../../auth/authentication_for_user.php");
include("./includes/header.php");
include("./includes/topbar.php");
include("./includes/sidebar.php");
?>

<?php
include("../../dB/config.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payslip Download</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .card {
      border-radius: 1rem;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .btn-download {
      font-size: 0.95rem;
    }
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-15">
        <div class="card p-4">
          <h3 class="text-center mb-4">Payslip Download</h3>
          <div class="table-responsive">
            <table class="table table-bordered table-striped">
              <thead class="table-dark">
                <tr>
                  <th>Month</th>
                  <th>Year</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>March</td>
                  <td>2025</td>
                  <td>
                    <a href="#" class="btn btn-primary btn-sm btn-download" download>
                      📄 Download PDF
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>February</td>
                  <td>2025</td>
                  <td>
                    <a href="#" class="btn btn-primary btn-sm btn-download" download>
                      📄 Download PDF
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>January</td>
                  <td>2025</td>
                  <td>
                    <a href="#" class="btn btn-primary btn-sm btn-download" download>
                      📄 Download PDF
                    </a>
                  </td>
                </tr>
                <!-- More rows can be added here -->
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>


<?php
include("./includes/footer.php");
?>