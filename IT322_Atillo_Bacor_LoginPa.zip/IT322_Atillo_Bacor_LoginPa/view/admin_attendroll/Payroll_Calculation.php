<?php
include("../../auth/authentication.php");
include("./includes/header.php");
include("./includes/topbar.php");
include("./includes/sidebar.php");
?>

<?php
include("../../dB/config.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payroll Calculation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #Title {
            font-size: 30px;
            font-weight: bold;
        }
        .btn-view {
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar bg-light px-4 py-2 shadow-sm">
        <span class="navbar-brand" id="Title">Payroll Management</span>
    </nav>

    <div class="container mt-4">
        <h4 class="mb-3">Payroll Summary</h4>

        <!-- Payroll Table -->
        <div class="card shadow-sm">
            <div class="card-body table-responsive">
                <table class="table table-striped text-center align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Employee</th>
                            <th>Days Worked</th>
                            <th>Basic Salary</th>
                            <th>OT Pay</th>
                            <th>Deductions</th>
                            <th>Net Pay</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Zail Gray Bacor</td>
                            <td>22</td>
                            <td>$1,500</td>
                            <td>$200</td>
                            <td>$100</td>
                            <td><strong class="text-success">$1,600</strong></td>
                            <td>
                                <button class="btn btn-sm bg-black text-white btn-view">View Payslip</button>
                            </td>
                        </tr>
                        <tr>
                            <td>Sherly Atillo</td>
                            <td>20</td>
                            <td>$1,500</td>
                            <td>$100</td>
                            <td>$50</td>
                            <td><strong class="text-success">$1,550</strong></td>
                            <td>
                                <button class="btn btn-sm bg-black text-white btn-view">View Payslip</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Export Button -->
        <div class="text-end mt-3">
            <button class="btn btn-success">Export Payroll Report</button>
        </div>
    </div>

    <!-- Bootstrap Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>



<?php
include("./includes/footer.php");
?>