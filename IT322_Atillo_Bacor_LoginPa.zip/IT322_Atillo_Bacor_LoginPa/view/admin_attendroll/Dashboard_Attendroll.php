<?php
include("../../auth/authentication.php");
include("./includes/header.php");
include("./includes/topbar.php");
include("./includes/sidebar.php");
?>

<?php
include("../../dB/config.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" type="image/png" href="../../assets/img/ATTEND ROLL.png">
    <title>Dashboard_Attendroll</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        #AP {
            background-color: white;
            border-radius: 20px;
        }
        #titleAP {
            color: black;
            font-size: 30px;
            font-weight: bold;
        }
        .card {
            border-radius: 1rem;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-light p-3 mb-3" id="AP">
        <h1 class="navbar-brand mb-0" id="titleAP">DASHBOARD</h1>
    </nav>

    <div class="container">
        <div class="row g-4">
            <!-- Present Card -->
            <div class="col-md-6">
                <div class="card bg-success text-white text-center">
                    <div class="card-body">
                        <h5 class="card-title">Employees Present</h5>
                        <p class="card-text fs-4 fw-bold">12 / 20</p>
                    </div>
                </div>
            </div>

            <!-- Absent Card -->
            <div class="col-md-6">
                <div class="card bg-danger text-white text-center">
                    <div class="card-body">
                        <h5 class="card-title">Absent Employees</h5>
                        <p class="card-text fs-4 fw-bold">8 / 20</p>
                    </div>
                </div>
            </div>

            <!-- Attendance Table -->
            <div class="col-12">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        Attendance Overview
                    </div>
                    <div class="card-body table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Name</th>
                                    <th>Status</th>
                                    <th>Time In</th>
                                    <th>Time Out</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Zail Gray Bacor</td>
                                    <td><span class="badge bg-success">Present</span></td>
                                    <td>08:00 AM</td>
                                    <td>05:00 PM</td>
                                </tr>
                                <tr>
                                    <td>Angelo Alejo</td>
                                    <td><span class="badge bg-danger">Absent</span></td>
                                    <td>-</td>
                                    <td>-</td>
                                </tr>
                                <tr>
                                    <td>Sherly Atillo</td>
                                    <td><span class="badge bg-success">Present</span></td>
                                    <td>08:10 AM</td>
                                    <td>05:00 PM</td>
                                </tr>
                                <tr>
                                    <td>John Barton</td>
                                    <td><span class="badge bg-success">Present</span></td>
                                    <td>08:05 AM</td>
                                    <td>04:55 PM</td>
                                </tr>
                                <tr>
                                    <td>Billy Joel</td>
                                    <td><span class="badge bg-danger">Absent</span></td>
                                    <td>-</td>
                                    <td>-</td>
                                </tr>
                                <!-- Add more dynamic rows here as needed -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>


<?php
include("./includes/footer.php");
?>


