<?php
include("../../auth/authentication.php");
include("./includes/header.php");
include("./includes/topbar.php");
include("./includes/sidebar.php");
?>

<?php
include("../../dB/config.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #Title {
            font-size: 28px;
            font-weight: bold;
        }
        .modal-header {
            background-color: #f8f9fa;
        }
        .btn-black {
            background-color: #000;
            color: #fff;
        }
        .btn-black:hover {
            background-color: #333;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar bg-light px-4 shadow-sm">
        <span class="navbar-brand mb-0 h1" id="Title">Employee Management</span>
    </nav>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4>Employee List</h4>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addEmployeeModal">
                + Add Employee
            </button>
        </div>

        <!-- Employee Table -->
        <div class="card shadow-sm">
            <div class="card-body table-responsive">
                <table class="table table-striped text-center align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Position</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>001</td>
                            <td>Zail Gray Bacor</td>
                            <td>Software Engineer</td>
                            <td>Zail@gmail.com</td>
                            <td>
                                <button class="btn btn-sm btn-black" data-bs-toggle="modal" data-bs-target="#editEmployeeModal">Edit</button>
                                <button class="btn btn-sm btn-danger">Remove</button>
                            </td>
                        </tr>
                        <tr>
                            <td>002</td>
                            <td>Sherly Atillo</td>
                            <td>HR Manager</td>
                            <td>Sherly@gmail.com</td>
                            <td>
                                <button class="btn btn-sm btn-black" data-bs-toggle="modal" data-bs-target="#editEmployeeModal">Edit</button>
                                <button class="btn btn-sm btn-danger">Remove</button>
                            </td>
                        </tr>
                        <!-- Add more employee rows dynamically if needed -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Employee Modal -->
    <div class="modal fade" id="addEmployeeModal" tabindex="-1" aria-labelledby="addEmployeeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content shadow-sm">
                <div class="modal-header">
                    <h5 class="modal-title" id="addEmployeeModalLabel">Add New Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addEmployeeForm">
                        <div class="mb-3">
                            <label for="empName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="empName" required>
                        </div>
                        <div class="mb-3">
                            <label for="empPosition" class="form-label">Position</label>
                            <input type="text" class="form-control" id="empPosition" required>
                        </div>
                        <div class="mb-3">
                            <label for="empEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="empEmail" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Save Employee</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Employee Modal -->
    <div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-labelledby="editEmployeeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content shadow-sm">
                <div class="modal-header">
                    <h5 class="modal-title" id="editEmployeeModalLabel">Edit Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editEmployeeForm">
                        <div class="mb-3">
                            <label for="editEmpName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="editEmpName" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEmpPosition" class="form-label">Position</label>
                            <input type="text" class="form-control" id="editEmpPosition" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEmpEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="editEmpEmail" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Update Employee</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>




<?php
include("./includes/footer.php");
?>