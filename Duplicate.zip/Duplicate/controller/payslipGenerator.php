<?php
session_start();
include("../dB/config.php");
require('fpdf/fpdf.php');

function generatePayslip($userId, $salaryId) {
    global $conn;
    
    // Get salary details
    $query = "SELECT s.*, u.firstName, u.lastName 
              FROM salary s 
              JOIN users u ON s.userId = u.userId 
              WHERE s.salaryId = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $salaryId);
    $stmt->execute();
    $result = $stmt->get_result();
    $salary = $result->fetch_assoc();
    
    // Generate PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',16);
    
    // Add payslip content
    $pdf->Cell(0,10,'PAYSLIP',0,1,'C');
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,10,'Employee: '.$salary['firstName'].' '.$salary['lastName'],0,1);
    $pdf->Cell(0,10,'Month: '.$salary['month'].'/'.$salary['year'],0,1);
    $pdf->Cell(0,10,'Basic Salary: $'.$salary['basicSalary'],0,1);
    $pdf->Cell(0,10,'Overtime: $'.$salary['overtime'],0,1);
    $pdf->Cell(0,10,'Deductions: $'.$salary['deductions'],0,1);
    $pdf->Cell(0,10,'Total Salary: $'.$salary['totalSalary'],0,1);
    
    // Save PDF
    $filename = 'payslips/'.$userId.'_'.$salaryId.'.pdf';
    $pdf->Output('F', $filename);
    
    // Update payslip table
    $query = "INSERT INTO payslip (userId, salaryId, pdfPath) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iis", $userId, $salaryId, $filename);
    
    return $stmt->execute();
}