<?php
session_start();
include("../dB/config.php");

function calculateSalary($userId, $month, $year) {
    global $conn;
    
    // Get basic salary
    $basicSalary = 20000.00; // Default basic salary
    
    // Calculate attendance
    $query = "SELECT COUNT(*) as present_days FROM attendance 
              WHERE userId = ? AND MONTH(date) = ? AND YEAR(date) = ? 
              AND status IN ('Present', 'Late')";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iii", $userId, $month, $year);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $presentDays = $row['present_days'];
    
    // Calculate overtime
    $overtime = 0;
    $query = "SELECT timeIn, timeOut FROM attendance 
              WHERE userId = ? AND MONTH(date) = ? AND YEAR(date) = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iii", $userId, $month, $year);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        if($row['timeOut'] > '17:00:00') {
            $overtime += (strtotime($row['timeOut']) - strtotime('17:00:00'))/3600;
        }
    }
    
    // Calculate total salary
    $overtimePay = $overtime * 200; // 200 per hour overtime
    $deductions = ($presentDays < 20) ? ($basicSalary * 0.1) : 0; // 10% deduction if less than 20 days present
    $totalSalary = $basicSalary + $overtimePay - $deductions;
    
    // Insert into salary table
    $query = "INSERT INTO salary (userId, basicSalary, overtime, deductions, month, year, totalSalary) 
              VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("idddiid", $userId, $basicSalary, $overtimePay, $deductions, $month, $year, $totalSalary);
    
    return $stmt->execute();
}