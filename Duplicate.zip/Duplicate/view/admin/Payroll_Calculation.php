<?php
include("../../auth/authentication.php");
include("./includes/header.php");
include("./includes/topbar.php");
include("./includes/sidebar.php");
include("../../dB/config.php");

// Get current month and year
$month = isset($_GET['month']) ? $_GET['month'] : date('m');
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');

// Calculate payroll for all employees
function calculatePayroll($userId, $month, $year, $conn) {
    // Count working days
    $query = "SELECT COUNT(*) as days_worked, 
              SUM(TIMESTAMPDIFF(HOUR, timeIn, timeOut)) as total_hours
              FROM attendance 
              WHERE userId = ? 
              AND MONTH(date) = ? 
              AND YEAR(date) = ?
              AND status IN ('Present', 'Late')";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iii", $userId, $month, $year);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    
    $daysWorked = $data['days_worked'] ?? 0;
    $totalHours = $data['total_hours'] ?? 0;
    
    // Only calculate salary if employee has worked days
    if($daysWorked > 0) {
        // Calculate overtime (hours worked beyond 8 hours per day)
        $regularHours = $daysWorked * 8;
        $overtimeHours = max(0, $totalHours - $regularHours);
        
        // Calculate pay
        $basicSalary = 20000.00; // Base salary per month
        $overtimeRate = 150.00;   // Overtime rate per hour
        $overtime = $overtimeHours * $overtimeRate;
        
        // Calculate deductions
        $deductions = 0;
        if ($daysWorked < 20) {
            $deductions = $basicSalary * 0.1; // 10% deduction for less than 20 days
        }
        
        $netPay = $basicSalary + $overtime - $deductions;
    } else {
        // No worked days = no salary
        $basicSalary = 0;
        $overtime = 0;
        $deductions = 0;
        $netPay = 0;
    }
    
    return [
        'daysWorked' => $daysWorked,
        'basicSalary' => $basicSalary,
        'overtimePay' => $overtime,
        'deductions' => $deductions,
        'netPay' => $netPay
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payroll Calculation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        #Title {
            font-size: 30px;
            font-weight: bold;
        }
        .btn-view {
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar bg-light px-4 py-2 shadow-sm">
        <span class="navbar-brand" id="Title">Payroll Management</span>
    </nav>

    <div class="container mt-4">
        <!-- Filter Section -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Month</label>
                        <select name="month" class="form-select">
                            <?php
                            for($m = 1; $m <= 12; $m++) {
                                $selected = $m == $month ? 'selected' : '';
                                echo "<option value='$m' $selected>" . date('F', mktime(0,0,0,$m,1)) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Year</label>
                        <select name="year" class="form-select">
                            <?php
                            $currentYear = date('Y');
                            for($y = $currentYear; $y >= $currentYear-2; $y--) {
                                $selected = $y == $year ? 'selected' : '';
                                echo "<option value='$y' $selected>$y</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">&nbsp;</label>
                        <button type="submit" class="btn btn-primary d-block">Filter</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-body table-responsive">
                <table class="table table-striped text-center align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Employee</th>
                            <th>Days Worked</th>
                            <th>Basic Salary</th>
                            <th>OT Pay</th>
                            <th>Deductions</th>
                            <th>Net Pay</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT userId, firstName, lastName FROM users WHERE userRole='user'";
                        $result = mysqli_query($conn, $query);
                        
                        while($employee = mysqli_fetch_assoc($result)) {
                            $payroll = calculatePayroll($employee['userId'], $month, $year, $conn);
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($employee['firstName'] . ' ' . $employee['lastName']); ?></td>
                            <td><?php echo $payroll['daysWorked']; ?></td>
                            <td><?php echo $payroll['daysWorked'] > 0 ? '₱'.number_format($payroll['basicSalary'], 2) : '-'; ?></td>
                            <td><?php echo $payroll['daysWorked'] > 0 ? '₱'.number_format($payroll['overtimePay'], 2) : '-'; ?></td>
                            <td><?php echo $payroll['daysWorked'] > 0 ? '₱'.number_format($payroll['deductions'], 2) : '-'; ?></td>
                            <td>
                                <?php if($payroll['daysWorked'] > 0): ?>
                                    <strong class="text-success">₱<?php echo number_format($payroll['netPay'], 2); ?></strong>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($payroll['daysWorked'] > 0): ?>
                                    <button class="btn btn-sm bg-black text-white btn-view" 
                                            onclick="generatePayslip(<?php echo $employee['userId']; ?>)">
                                        View Payslip
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-sm bg-secondary" disabled>No Payslip</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Export Button -->
        <div class="text-end mt-3">
            <button class="btn btn-success" onclick="exportPayroll()">Export Payroll Report</button>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.all.min.js"></script>
    <script>
    function generatePayslip(userId) {
        fetch('../../controller/payslipGenerator.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `userId=${userId}&month=${<?php echo $month; ?>}&year=${<?php echo $year; ?>}`
        })
        .then(response => response.json())
        .then(data => {
            if(data.status === 'success') {
                window.open(data.pdfUrl, '_blank');
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: data.message
                });
            }
        });
    }

    function exportPayroll() {
        window.location.href = `../../controller/payrollExport.php?month=${<?php echo $month; ?>}&year=${<?php echo $year; ?>}`;
    }
    </script>
</body>
</html>

<?php include("./includes/footer.php"); ?>