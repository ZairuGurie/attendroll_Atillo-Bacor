          <div class="card">
            <div class="card-body">
              <button class="btn btn-primary" style="margin-left: 1420px; margin-top: 10px; background-color: black;">
                <a href="../../register.php" style="color: white; text-decoration: none;"><b>Add User</b></a>
              </button>
              <table class="table datatable">
                <thead>
                  <tr>
                    <th>
                      <b>Fullname</b>
                    </th>
                    <th>Mobile Number</th>
                    <th>Gender</th>
                    <th data-type="date" data-format="YYYY/DD/MM">Birthday</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php 
                    $query = "SELECT `firstName`, `lastName`, `phoneNumber`, `gender`, `birthday` FROM `users`";
                    $query_run = mysqli_query($conn, $query);

                    if (!$query_run) {
                        die("Query failed: " . mysqli_error($conn));
                    }
                    if (mysqli_num_rows($query_run) > 0) {
                        while ($row = mysqli_fetch_assoc($query_run)) {
                            ?>
                            <tr>
                                <td><?php echo $row['firstName'] . " " . $row['lastName']; ?></td>
                                <td><?php echo $row['phoneNumber']; ?></td>
                                <td><?php echo $row['gender']; ?></td>
                                <td><?php echo $row['birthday']; ?></td>
                                <td><button class="bi bi-eye-fill"></button></td>
                            </tr>
                            <?php
                        }
                    }
                ?>
                </tbody>
              </table>

            </div>
          </div>