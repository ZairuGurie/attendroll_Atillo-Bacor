<?php
include("../../auth/authentication_for_user.php");
include("./includes/header.php");
include("./includes/topbar.php");
include("./includes/sidebar.php");
include("../../dB/config.php");

// Get current user's ID
$userId = $_SESSION['authUser']['userId'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payslip Download</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .card {
      border-radius: 1rem;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .btn-download {
      font-size: 0.95rem;
    }
    .salary-details {
      font-size: 0.9rem;
      color: #6c757d;
    }
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-15">
        <div class="card p-4">
          <h3 class="text-center mb-4">Payslip Records</h3>
          
          <!-- Filter Section -->
          <div class="mb-4">
            <form method="GET" class="row g-3">
              <div class="col-md-4">
                <select name="month" class="form-select">
                  <?php
                  $selected_month = isset($_GET['month']) ? $_GET['month'] : date('m');
                  for($m = 1; $m <= 12; $m++) {
                    $month_name = date('F', mktime(0, 0, 0, $m, 1));
                    $selected = ($m == $selected_month) ? 'selected' : '';
                    echo "<option value='$m' $selected>$month_name</option>";
                  }
                  ?>
                </select>
              </div>
              <div class="col-md-4">
                <select name="year" class="form-select">
                  <?php
                  $current_year = date('Y');
                  $selected_year = isset($_GET['year']) ? $_GET['year'] : $current_year;
                  for($y = $current_year; $y >= $current_year - 2; $y--) {
                    $selected = ($y == $selected_year) ? 'selected' : '';
                    echo "<option value='$y' $selected>$y</option>";
                  }
                  ?>
                </select>
              </div>
              <div class="col-md-4">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
              </div>
            </form>
          </div>

          <div class="table-responsive">
            <table class="table table-bordered table-hover">
              <thead class="table-dark">
                <tr>
                  <th>Period</th>
                  <th>Basic Salary</th>
                  <th>Overtime</th>
                  <th>Deductions</th>
                  <th>Net Pay</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                // Get payroll records for the selected month and year
                $month = isset($_GET['month']) ? $_GET['month'] : date('m');
                $year = isset($_GET['year']) ? $_GET['year'] : date('Y');

                $query = "SELECT s.*, p.pdfPath 
                         FROM salary s 
                         LEFT JOIN payslip p ON s.salaryId = p.salaryId
                         WHERE s.userId = ? AND s.month = ? AND s.year = ?
                         ORDER BY s.year DESC, s.month DESC";

                // Add error handling for prepare statement
                $stmt = $conn->prepare($query);
                if($stmt === false) {
                    die("Error preparing statement: " . $conn->error);
                }

                $stmt->bind_param("iii", $userId, $month, $year);
                $stmt->execute();
                $result = $stmt->get_result();

                if($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        // Format the period
                        $period = date('F Y', mktime(0, 0, 0, $row['month'], 1, $row['year']));
                        
                        // Get status badge class
                        $statusClass = $row['status'] === 'Paid' ? 'bg-success' : 'bg-warning';
                ?>
                <tr>
                    <td><?php echo $period; ?></td>
                    <td>₱<?php echo number_format($row['basicSalary'], 2); ?></td>
                    <td>₱<?php echo number_format($row['overtime'], 2); ?></td>
                    <td>₱<?php echo number_format($row['deductions'], 2); ?></td>
                    <td><strong>₱<?php echo number_format($row['totalSalary'], 2); ?></strong></td>
                    <td><span class="badge <?php echo $statusClass; ?>"><?php echo $row['status']; ?></span></td>
                    <td>
                        <?php if($row['pdfPath']): ?>
                            <a href="../../<?php echo $row['pdfPath']; ?>" 
                               class="btn btn-primary btn-sm btn-download" 
                               download>
                              📄 Download
                            </a>
                        <?php else: ?>
                            <button class="btn btn-primary btn-sm" 
                                    onclick="generatePayslip(<?php echo $row['salaryId']; ?>)">
                              Generate PDF
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php 
                  }
                } else {
                ?>
                <tr>
                  <td colspan="7" class="text-center text-muted py-4">
                    No payslip records found for this period
                  </td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>

          <!-- Monthly Summary -->
          <?php if($result->num_rows > 0): ?>
          <div class="mt-4">
            <h5>Monthly Summary</h5>
            <?php
            // Calculate monthly totals
            $totalQuery = "SELECT 
                SUM(basicSalary) as total_basic,
                SUM(overtime) as total_overtime,
                SUM(bonus) as total_bonus,
                SUM(deductions) as total_deductions,
                SUM(totalSalary) as total_net
                FROM salary 
                WHERE userId = ? AND month = ? AND year = ?";

            $totalStmt = $conn->prepare($totalQuery);
            $totalStmt->bind_param("iii", $userId, $month, $year);
            $totalStmt->execute();
            $totals = $totalStmt->get_result()->fetch_assoc();
            ?>
            <div class="row g-3">
              <div class="col-md-3">
                <div class="p-3 border rounded bg-light">
                  <small class="d-block text-muted">Basic Salary</small>
                  <strong>₱<?php echo number_format($totals['total_basic'], 2); ?></strong>
                </div>
              </div>
              <div class="col-md-3">
                <div class="p-3 border rounded bg-light">
                  <small class="d-block text-muted">Total Overtime</small>
                  <strong>₱<?php echo number_format($totals['total_overtime'], 2); ?></strong>
                </div>
              </div>
              <div class="col-md-3">
                <div class="p-3 border rounded bg-light">
                  <small class="d-block text-muted">Total Deductions</small>
                  <strong>₱<?php echo number_format($totals['total_deductions'], 2); ?></strong>
                </div>
              </div>
              <div class="col-md-3">
                <div class="p-3 border rounded bg-success text-white">
                  <small class="d-block">Total Net Pay</small>
                  <strong>₱<?php echo number_format($totals['total_net'], 2); ?></strong>
                </div>
              </div>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
  function generatePayslip(salaryId) {
    Swal.fire({
      title: 'Generating Payslip...',
      text: 'Please wait while we generate your PDF',
      allowOutsideClick: false,
      didOpen: () => {
        Swal.showLoading();
        fetch('../../controller/payslipGenerator.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: `salaryId=${salaryId}`
        })
        .then(response => response.json())
        .then(data => {
          if(data.status === 'success') {
            Swal.fire({
              icon: 'success',
              title: 'Success',
              text: 'Payslip generated successfully'
            }).then(() => {
              window.location.reload();
            });
          } else {
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: data.message
            });
          }
        });
      }
    });
  }
  </script>
</body>
</html>

<?php include("./includes/footer.php"); ?>