<?php
include("../../auth/authentication_for_user.php");
include("./includes/header.php");
include("./includes/topbar.php");
include("./includes/sidebar.php");
include("../../dB/config.php");
?>

<?php
include("../../dB/config.php");
?>


<?php
include("Salary_Details.php");
?>

<?php
include("./includes/footer.php");
?>